package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ShowPatient extends JFrame {
    private DefaultTableModel model;
    private JTable table;

    public ShowPatient() {
        // Create panel
        JPanel panelPatient = new JPanel();
        panelPatient.setBounds(5, 5, 910, 470);
        panelPatient.setBackground(new Color(230, 245, 255));
        panelPatient.setLayout(null);
        this.add(panelPatient);

        // Create table model with columns from image
        model = new DefaultTableModel();
        table = new JTable(model);

        // Add columns according to the image
        model.addColumn("patient_id");
        model.addColumn("patient_name");
        model.addColumn("age");
        model.addColumn("status");
        model.addColumn("reserved_time");
        model.addColumn("username");
        model.addColumn("password");

        // Add scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 30, 900, 380);
        panelPatient.add(scrollPane);

        // Load data from database
        loadPatientData();

        // Back button
        JButton buttonBack = new JButton("BACK");
        buttonBack.setBounds(400, 420, 120, 30);
        buttonBack.setBackground(new Color(120, 140, 170));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.addActionListener(e -> setVisible(false));
        panelPatient.add(buttonBack);

        // Frame settings
        this.setUndecorated(true);
        this.setSize(920, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadPatientData() {
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT patient_id, patient_name, age, status, reserved_time, username, password FROM patient";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getInt("age"),
                        rs.getString("status"),
                        rs.getString("reserved_time"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading patient data: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new ShowPatient();
    }
}