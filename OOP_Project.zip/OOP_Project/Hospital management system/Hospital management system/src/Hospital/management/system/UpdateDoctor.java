package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdateDoctor extends JFrame {
    private JTextField textCurrentID, textNewID, textDoctorName, textDoctorSpetiality, textDoctorSalary, textDoctorPhone;
    private Choice choiceDepartment;

    public UpdateDoctor() {
        // إنشاء اللوحة الرئيسية
        JPanel panelDoctor = new JPanel();
        panelDoctor.setBounds(5, 5, 910, 510);
        panelDoctor.setBackground(new Color(200, 225, 245));
        panelDoctor.setLayout(null);
        this.add(panelDoctor);

        // إضافة الأيقونة
        ImageIcon updateDoctorIcon = new ImageIcon("UpdateDoctor.png");
        Image image = updateDoctorIcon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
        JLabel labelIcon = new JLabel(new ImageIcon(image));
        labelIcon.setBounds(500, 60, 300, 300);
        panelDoctor.add(labelIcon);

        // العنوان الرئيسي
        JLabel labelTitle = new JLabel("Update Doctor");
        labelTitle.setBounds(124, 11, 222, 25);
        labelTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        panelDoctor.add(labelTitle);

        // الحقول الحالية
        addCurrentIdFields(panelDoctor);
        addNewIdFields(panelDoctor);
        addNameFields(panelDoctor);
        addSpecialtyFields(panelDoctor);
        addSalaryFields(panelDoctor);
        addPhoneFields(panelDoctor);
        addDepartmentFields(panelDoctor);
        addButtons(panelDoctor);

        // إعدادات النافذة
        this.setUndecorated(true);
        this.setSize(920, 520);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void addCurrentIdFields(JPanel panel) {
        JLabel label = new JLabel("Current ID:");
        label.setBounds(25, 60, 100, 20);
        panel.add(label);

        textCurrentID = new JTextField();
        textCurrentID.setBounds(160, 60, 140, 20);
        panel.add(textCurrentID);
    }

    private void addNewIdFields(JPanel panel) {
        JLabel label = new JLabel("New ID:");
        label.setBounds(25, 90, 100, 20);
        panel.add(label);

        textNewID = new JTextField();
        textNewID.setBounds(160, 90, 140, 20);
        panel.add(textNewID);
    }

    private void addNameFields(JPanel panel) {
        JLabel label = new JLabel("New Name:");
        label.setBounds(25, 120, 100, 20);
        panel.add(label);

        textDoctorName = new JTextField();
        textDoctorName.setBounds(160, 120, 140, 20);
        panel.add(textDoctorName);
    }

    private void addSpecialtyFields(JPanel panel) {
        JLabel label = new JLabel("New Specialty:");
        label.setBounds(25, 150, 100, 20);
        panel.add(label);

        textDoctorSpetiality = new JTextField();
        textDoctorSpetiality.setBounds(160, 150, 140, 20);
        panel.add(textDoctorSpetiality);
    }

    private void addSalaryFields(JPanel panel) {
        JLabel label = new JLabel("New Salary:");
        label.setBounds(25, 180, 100, 20);
        panel.add(label);

        textDoctorSalary = new JTextField();
        textDoctorSalary.setBounds(160, 180, 140, 20);
        panel.add(textDoctorSalary);
    }

    private void addPhoneFields(JPanel panel) {
        JLabel label = new JLabel("New Phone:");
        label.setBounds(25, 210, 100, 20);
        panel.add(label);

        textDoctorPhone = new JTextField();
        textDoctorPhone.setBounds(160, 210, 140, 20);
        panel.add(textDoctorPhone);
    }

    private void addDepartmentFields(JPanel panel) {
        JLabel label = new JLabel("Department:");
        label.setBounds(25, 240, 100, 20);
        panel.add(label);

        choiceDepartment = new Choice();
        choiceDepartment.setBounds(160, 240, 140, 20);
        loadDepartments();
        panel.add(choiceDepartment);
    }

    private void addButtons(JPanel panel) {
        JButton updateButton = new JButton("Update");
        updateButton.setBounds(100, 300, 100, 30);
        updateButton.addActionListener(this::performUpdate);
        panel.add(updateButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(220, 300, 100, 30);
        backButton.addActionListener(e -> dispose());
        panel.add(backButton);
    }

    private void loadDepartments() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:/ObjectOrianted_Project/HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT dept_name FROM department")) {

            while (rs.next()) {
                choiceDepartment.add(rs.getString("dept_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading departments: " + ex.getMessage());
        }
    }

    private void performUpdate(ActionEvent e) {
        try {
            int currentId = Integer.parseInt(textCurrentID.getText());
            int newId = Integer.parseInt(textNewID.getText());
            String name = textDoctorName.getText();
            String specialty = textDoctorSpetiality.getText();
            int salary = Integer.parseInt(textDoctorSalary.getText());
            String phone = textDoctorPhone.getText();
            String department = choiceDepartment.getSelectedItem();

            String sql = "UPDATE Doctor SET id=?, name=?, speciality=?, salary=?, phone=?, department_id=? WHERE id=?";

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:/ObjectOrianted_Project/HospitalDB.db");
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, newId);
                pstmt.setString(2, name);
                pstmt.setString(3, specialty);
                pstmt.setInt(4, salary);
                pstmt.setString(5, phone);
                pstmt.setString(6, department);
                pstmt.setInt(7, currentId);

                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Update successful!");
                } else {
                    JOptionPane.showMessageDialog(this, "No doctor found with this ID");
                }
            }
        } catch (NumberFormatException | SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new UpdateDoctor();
    }
}