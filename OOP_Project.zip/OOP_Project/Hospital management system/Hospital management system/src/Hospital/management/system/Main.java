package Hospital.management.system;


public class Main {
    public static void main(String[] args){
      MainFrame mainFrame = new MainFrame();

//        Reception reception = new Reception();
    }
}
