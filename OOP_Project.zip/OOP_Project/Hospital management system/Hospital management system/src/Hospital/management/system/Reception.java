package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reception extends JFrame {

    Reception(){
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(5,160,1525,670);
        panel.setBackground(new Color(220, 235, 247));
        this.add(panel);

        JPanel panelButt = new JPanel();
        panelButt.setLayout(null);
        panelButt.setBounds(5,5,1525,150);
        panelButt.setBackground(new Color(220, 235, 247));
        this.add(panelButt);

        ImageIcon imageIcon = new ImageIcon("drPanel.png");
        Image image = imageIcon.getImage().getScaledInstance(250,250,Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(image));
        label.setBounds(1100,0,250,250);
        panelButt.add(label);

        ImageIcon imageIconAmb = new ImageIcon("amblogo.png");
        Image image1 = imageIconAmb.getImage().getScaledInstance(250,200,Image.SCALE_SMOOTH);
        JLabel labelAmb = new JLabel(new ImageIcon(image1));
        labelAmb.setBounds(865,50,300,100);
        panelButt.add(labelAmb);

        addButton(panelButt, "Add User", 30, 15, () -> new AddUser());
        addButton(panelButt, "Remove User", 30, 58, () -> new RemoveUser());
        addButton(panelButt, "Update User", 30, 100, () -> new UpdateUser());
        addButton(panelButt, "Show User", 270, 15, () -> new ShowUser());
        addButton(panelButt, "Search User", 270, 58, () -> new SearchUser());
        addButton(panelButt, "Doctor Management", 270, 100, () -> new DoctorManagement());
        addButton(panelButt, "Patient Management", 510, 15, () -> new PatientManagement());
        addButton(panelButt, "Logout", 750, 15, () -> { setVisible(false); new MainFrame(); });
        addButton(panelButt, "Prescription", 750, 58, () -> new PrescriptionForm());
        addButton(panelButt, "Appointment", 750, 100, () -> new AppointmentForm());

        this.setSize(1950,1090);
        this.getContentPane().setBackground(Color.WHITE);
        this.setLayout(null);
        this.setVisible(true);
    }

    private void addButton(JPanel panel, String text, int x, int y, Runnable action) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 30);
        button.setFocusable(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.addActionListener(e -> action.run());
        panel.add(button);
    }

}