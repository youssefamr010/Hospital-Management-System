package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class SearchDoctor extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;

    public SearchDoctor() {
        // إنشاء اللوحة الرئيسية
        JPanel panelDoctor = new JPanel();
        panelDoctor.setBounds(5, 5, 910, 470);
        panelDoctor.setBackground(new Color(230, 245, 255));
        panelDoctor.setLayout(null);
        this.add(panelDoctor);

        // عنوان النافذة
        JLabel labelTitle = new JLabel("Search For Doctor");
        labelTitle.setBounds(250, 11, 250, 31);
        labelTitle.setForeground(new Color(40, 70, 110));
        labelTitle.setFont(new Font("Arial", Font.BOLD, 20));
        panelDoctor.add(labelTitle);

        // حقل البحث
        JLabel labelIDSearch = new JLabel("Doctor ID/Name:");
        labelIDSearch.setBounds(50, 73, 120, 20);
        labelIDSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panelDoctor.add(labelIDSearch);

        searchField = new JTextField();
        searchField.setBounds(175, 73, 200, 30);
        panelDoctor.add(searchField);

        // إنشاء نموذج الجدول
        model = new DefaultTableModel();
        table = new JTable(model);
        table.setFont(new Font("Tahoma", Font.PLAIN, 12));

        // تعريف الأعمدة حسب الصورة المرفقة
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Specialty");
        model.addColumn("Department ID");
        model.addColumn("Salary");
        model.addColumn("Phone");
        model.addColumn("Username");
        model.addColumn("Password");

        // إضافة الجدول إلى JScrollPane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 150, 890, 250);
        panelDoctor.add(scrollPane);

        // زر البحث
        JButton searchButton = new JButton("Search");
        searchButton.setBounds(200, 420, 120, 25);
        searchButton.setBackground(new Color(60, 100, 130));
        searchButton.setForeground(Color.white);
        searchButton.addActionListener(this::searchAction);
        panelDoctor.add(searchButton);

        // زر الرجوع
        JButton buttonBack = new JButton("BACK");
        buttonBack.setBounds(450, 420, 120, 30);
        buttonBack.setBackground(new Color(120, 140, 170));
        buttonBack.setForeground(Color.white);
        buttonBack.addActionListener(e -> setVisible(false));
        panelDoctor.add(buttonBack);

        // تحميل البيانات الأولية
        loadAllDoctors();

        // إعدادات النافذة
        this.setUndecorated(true);
        this.setSize(920, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadAllDoctors() {
        String db_url = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM Doctor";

        try (Connection conn = DriverManager.getConnection(db_url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("speciality"),
                        rs.getInt("department_id"),
                        rs.getDouble("salary"),
                        rs.getString("phone"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    private void searchAction(ActionEvent e) {
        String searchTerm = searchField.getText().trim();
        if (searchTerm.isEmpty()) {
            loadAllDoctors();
            return;
        }

        String db_url = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM Doctor WHERE id = ? OR name LIKE ?";

        try (Connection conn = DriverManager.getConnection(db_url);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, searchTerm);
            pstmt.setString(2, "%" + searchTerm + "%");

            ResultSet rs = pstmt.executeQuery();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("speciality"),
                        rs.getInt("department_id"),
                        rs.getDouble("salary"),
                        rs.getString("phone"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }
    }

}