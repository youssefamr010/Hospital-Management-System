package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class ShowDoctor extends JFrame {
    private DefaultTableModel model;
    private JTable table;

    public ShowDoctor() {
        // Create panel
        JPanel panelDoctor = new JPanel();
        panelDoctor.setBounds(5, 5, 910, 470);
        panelDoctor.setBackground(new Color(230, 245, 255));
        panelDoctor.setLayout(null);
        this.add(panelDoctor);

        // Create table model
        model = new DefaultTableModel();
        table = new JTable(model);

        // Add columns according to database structure
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Specialty");
        model.addColumn("Department ID");
        model.addColumn("Salary");
        model.addColumn("Phone");

        // Add scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 30, 900, 380);
        panelDoctor.add(scrollPane);

        // Load data from database
        loadDoctorData();

        // Back button
        JButton buttonBack = new JButton("BACK");
        buttonBack.setBounds(400, 420, 120, 30);
        buttonBack.setBackground(new Color(120, 140, 170));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.addActionListener(e -> setVisible(false));
        panelDoctor.add(buttonBack);

        // Frame settings
        this.setUndecorated(true);
        this.setSize(920, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadDoctorData() {
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM Doctor";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("speciality"),
                        rs.getInt("department_id"),
                        rs.getDouble("salary"),
                        rs.getString("phone")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading doctor data: " + ex.getMessage());
        }
    }

}