package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class SearchUser extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField searchField;

    public SearchUser() {
        // Main panel setup
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 690, 490);
        panel.setBackground(new Color(200, 220, 240));
        panel.setLayout(null);
        this.add(panel);

        // Window title
        JLabel labelTitle = new JLabel("Search For User");
        labelTitle.setBounds(220, 11, 250, 31);
        labelTitle.setFont(new Font("Arial", Font.BOLD, 20));
        labelTitle.setForeground(new Color(40, 70, 110));
        panel.add(labelTitle);

        // Search components
        JLabel labelSearch = new JLabel("User ID/Name:");
        labelSearch.setBounds(50, 73, 120, 20);
        labelSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panel.add(labelSearch);

        searchField = new JTextField();
        searchField.setBounds(175, 73, 200, 30);
        panel.add(searchField);

        // Table setup with columns from image
        model = new DefaultTableModel();
        table = new JTable(model);
        model.addColumn("userid");
        model.addColumn("username");
        model.addColumn("userphonenumber");
        model.addColumn("user_email");
        model.addColumn("user_password");

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 150, 670, 250);
        panel.add(scrollPane);

        // Control buttons
        JButton searchButton = new JButton("Search");
        searchButton.setBounds(200, 420, 120, 25);
        searchButton.setBackground(new Color(60, 100, 130));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(this::searchAction);
        panel.add(searchButton);

        JButton backButton = new JButton("BACK");
        backButton.setBounds(380, 420, 120, 25);
        backButton.setBackground(new Color(50, 85, 110));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> setVisible(false));
        panel.add(backButton);

        // Initial data load
        loadAllUsers();

        // Window settings
        this.setUndecorated(true);
        this.setSize(700, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadAllUsers() {
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM users_table";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("userid"),
                        rs.getString("username"),
                        rs.getString("userphonenumber"),
                        rs.getString("user_email"),
                        rs.getString("user_password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    private void searchAction(ActionEvent e) {
        String searchTerm = searchField.getText().trim();
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM users_table WHERE userid = ? OR username LIKE ?";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, searchTerm);
            pstmt.setString(2, "%" + searchTerm + "%");

            ResultSet rs = pstmt.executeQuery();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("userid"),
                        rs.getString("username"),
                        rs.getString("userphonenumber"),
                        rs.getString("user_email"),
                        rs.getString("user_password")
                });
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No matching records found");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new SearchUser();
    }
}