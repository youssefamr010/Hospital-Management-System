package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class UpdatePatient extends JFrame {
    private JTextField textCurrentID, textNewID, textPatientName, textPatientAge, textPatientStatus, textReserveTime, textUsername;
    private JPasswordField textPassword;

    public UpdatePatient() {
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 910, 510);
        panel.setBackground(new Color(200, 225, 245));
        panel.setLayout(null);
        add(panel);

        ImageIcon icon = new ImageIcon("patient.png");
        Image img = icon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
        JLabel imgLabel = new JLabel(new ImageIcon(img));
        imgLabel.setBounds(550, 60, 300, 300);
        panel.add(imgLabel);

        JLabel title = new JLabel("Update Patient Record");
        title.setBounds(50, 20, 300, 30);
        title.setFont(new Font("Tahoma", Font.BOLD, 20));
        panel.add(title);

        addField(panel, "Current ID:", 50, 70, textCurrentID = new JTextField(), 150, 70);
        addField(panel, "New ID:", 50, 110, textNewID = new JTextField(), 150, 110);
        addField(panel, "Full Name:", 50, 150, textPatientName = new JTextField(), 150, 150);
        addField(panel, "Age:", 50, 190, textPatientAge = new JTextField(), 150, 190);
        addField(panel, "Status:", 50, 230, textPatientStatus = new JTextField(), 150, 230);
        addField(panel, "Reservation Time:", 50, 270, textReserveTime = new JTextField(), 150, 270);
        addField(panel, "Username:", 50, 310, textUsername = new JTextField(), 150, 310);
        addField(panel, "Password:", 50, 350, textPassword = new JPasswordField(), 150, 350);

        JButton updateBtn = new JButton("Update");
        updateBtn.setBounds(50, 390, 100, 30);
        updateBtn.setBackground(Color.decode("#2196F3"));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.addActionListener(this::updateAction);
        panel.add(updateBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(180, 390, 100, 30);
        backBtn.setBackground(Color.GRAY);
        backBtn.setForeground(Color.WHITE);
        backBtn.addActionListener(e -> dispose());
        panel.add(backBtn);

        setUndecorated(true);
        setSize(920, 520);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addField(JPanel panel, String labelText, int x, int y, JTextField field, int fieldX, int fieldY) {
        JLabel label = new JLabel(labelText);
        label.setBounds(x, y, 110, 20);
        panel.add(label);
        field.setBounds(fieldX, fieldY, 200, 25);
        panel.add(field);
    }

    private void updateAction(ActionEvent e) {
        String currentID = textCurrentID.getText();
        String newID = textNewID.getText();
        String name = textPatientName.getText();
        String age = textPatientAge.getText();
        String status = textPatientStatus.getText();
        String resTime = textReserveTime.getText();
        String username = textUsername.getText();
        String password = new String(textPassword.getPassword());

        if (currentID.isEmpty() || newID.isEmpty() || name.isEmpty() || age.isEmpty() || status.isEmpty() || resTime.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Fill all fields");
            return;
        }

        try {
            int ageValue = Integer.parseInt(age);
            if (ageValue <= 0) throw new NumberFormatException();

            String sql = "UPDATE patient SET patient_id=?, patient_name=?, age=?, status=?, reserved_time=?, username=?, password=? WHERE patient_id=?";

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, newID);
                pstmt.setString(2, name);
                pstmt.setInt(3, ageValue);
                pstmt.setString(4, status);
                pstmt.setString(5, resTime);
                pstmt.setString(6, username);
                pstmt.setString(7, password);
                pstmt.setString(8, currentID);

                if (pstmt.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(this, "Update successful");
                    textCurrentID.setText("");
                    textNewID.setText("");
                    textPatientName.setText("");
                    textPatientAge.setText("");
                    textPatientStatus.setText("");
                    textReserveTime.setText("");
                    textUsername.setText("");
                    textPassword.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Patient not found");
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid age");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error");
            System.out.println(ex.getMessage());
        }
    }


}