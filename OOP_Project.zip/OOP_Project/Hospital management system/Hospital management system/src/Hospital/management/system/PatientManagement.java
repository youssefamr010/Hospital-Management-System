package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PatientManagement extends JFrame {
    PatientManagement(){
//      Create panel to show when click the button
        JPanel showPanel = new JPanel();
        showPanel.setLayout(null);
        showPanel.setBounds(200, 5, 1115, 540);
        showPanel.setBackground(new Color(240, 248, 255));
        this.add(showPanel);

//     Create panel to with buttons
        JPanel panelButtons = new JPanel();
        panelButtons.setLayout(null);
        panelButtons.setBounds(5,5,190,540);
        panelButtons.setBackground(new Color(200, 225, 240) );
        this.add(panelButtons);

//     Add  Image Icon for show panel
        ImageIcon imageIcon = new ImageIcon("patient.png");
        Image image = imageIcon.getImage().getScaledInstance(450,450,Image.SCALE_SMOOTH);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel labelImage = new JLabel(imageIcon1);
        labelImage.setBounds(250,20,450,450);
        showPanel.add(labelImage);

//     Add  Image Icon for button panel
        ImageIcon imageIconButt = new ImageIcon("drb.png");
        Image imageButt = imageIconButt.getImage().getScaledInstance(180,250,Image.SCALE_SMOOTH);
        ImageIcon imageIconButt1 = new ImageIcon(imageButt);
        JLabel labelImageButt = new JLabel(imageIconButt1);
        labelImageButt.setBounds(2,260,180,250);
        panelButtons.add(labelImageButt);
//     Create button to add Doctor
        JButton addButton = new JButton("Add Patient");
        addButton.setBounds(10,30,170,30);
        addButton.setBackground(new Color(100, 149, 237));
        addButton.setForeground(Color.white);
        addButton.setFocusable(false);
        panelButtons.add(addButton);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new AddPatient();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

//     Create button to remove Doctor
        JButton removeButton = new JButton("Remove Patient");
        removeButton.setBounds(10,70,170,30);
        removeButton.setBackground(new Color(100, 149, 237));
        removeButton.setForeground(Color.white);
        removeButton.setFocusable(false);
        panelButtons.add(removeButton);
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    setVisible(false);
                    new RemovePatient();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

//     Create button to Update Patient
        JButton updateButton = new JButton("Update Patient");
        updateButton.setBounds(10,110,170,30);
        updateButton.setBackground(new Color(100, 149, 237));
        updateButton.setForeground(Color.white);
        updateButton.setFocusable(false);
        panelButtons.add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new UpdatePatient();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

//     Create button to Show Doctor
        JButton showButton = new JButton("Show Patient");
        showButton.setBounds(10,150,170,30);
        showButton.setBackground(new Color(100, 149, 237));
        showButton.setForeground(Color.white);
        showButton.setFocusable(false);
        panelButtons.add(showButton);
        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new ShowPatient();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

//     Create button to Search Doctor
        JButton searchButton = new JButton("Search Patient");
        searchButton.setBounds(10,190,170,30);
        searchButton.setBackground(new Color(100, 149, 237));
        searchButton.setForeground(Color.white);
        searchButton.setFocusable(false);
        panelButtons.add(searchButton);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    new SearchPatient();
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

//     Create button to backButton
        JButton backButton = new JButton("Back");
        backButton.setBounds(10,230,170,30);
        backButton.setBackground(new Color(72, 130, 180));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusable(false);
        panelButtons.add(backButton);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    setVisible(false);
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });


        this.setUndecorated(true);
        this.getContentPane().setBackground(Color.WHITE);
        this.setLayout(null);
        this.setSize(1125, 550);
        this.setVisible(true);
        this.setLocation(150,200);
    }
}
