package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class AddUser extends JFrame implements ActionListener {
    JTextField textFieldName, textFieldPhone, textFieldEmail, textFieldID;
    JPasswordField passwordField;
    JButton backButton, addButton;

    public AddUser(){
        // إنشاء اللوحة الرئيسية
        JPanel panel = new JPanel();
        panel.setBounds(5,5,840,440);
        panel.setBackground(new Color(200, 220, 240));
        panel.setLayout(null);
        this.add(panel);

        // إضافة الأيقونة
        ImageIcon  imageIcon = new ImageIcon("userLogo.png");
        Image image = imageIcon.getImage().getScaledInstance(400,400,Image.SCALE_SMOOTH);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(450,80,400,350);
        panel.add(label);

        // عنوان النافذة
        JLabel labelTitle = new JLabel("Add User");
        labelTitle.setBounds(118,11,260,53);
        labelTitle.setFont(new Font("Tahoma",Font.BOLD,20));
        labelTitle.setForeground(new Color(20, 40, 60));
        panel.add(labelTitle);

        // إضافة حقل User ID الجديد
        JLabel labelID = new JLabel("User ID:");
        labelID.setBounds(35,85,200,14);
        labelID.setFont(new Font("Tahoma",Font.BOLD,14));
        labelID.setForeground(new Color(60, 80, 100));
        panel.add(labelID);

        textFieldID = new JTextField();
        textFieldID.setBounds(200,85,150,20);
        panel.add(textFieldID);

        // تعديل مواقع الحقول القديمة
        // User Name
        JLabel labelName = new JLabel("User Name:");
        labelName.setBounds(35,120,200,14); // تم تغيير Y من 85 إلى 120
        labelName.setFont(new Font("Tahoma",Font.BOLD,14));
        labelName.setForeground(new Color(60, 80, 100));
        panel.add(labelName);

        textFieldName = new JTextField();
        textFieldName.setBounds(200,120,150,20); // تم تغيير Y من 85 إلى 120
        panel.add(textFieldName);

        // Phone Number
        JLabel labelNumber = new JLabel("User PhoneNumber:");
        labelNumber.setBounds(35,155,200,14); // تم تغيير Y من 120 إلى 155
        labelNumber.setFont(new Font("Tahoma",Font.BOLD,14));
        labelNumber.setForeground(new Color(60, 80, 100));
        panel.add(labelNumber);

        textFieldPhone = new JTextField();
        textFieldPhone.setBounds(200,155,150,20); // تم تغيير Y من 120 إلى 155
        panel.add(textFieldPhone);

        // Email
        JLabel labelEmail = new JLabel("User Email:");
        labelEmail.setBounds(35,190,200,14); // تم تغيير Y من 157 إلى 190
        labelEmail.setFont(new Font("Tahoma",Font.BOLD,14));
        labelEmail.setForeground(new Color(60, 80, 100));
        panel.add(labelEmail);

        textFieldEmail = new JTextField();
        textFieldEmail.setBounds(200,190,150,20); // تم تغيير Y من 157 إلى 190
        panel.add(textFieldEmail);

        // Password
        JLabel labelPass = new JLabel("User Password:");
        labelPass.setBounds(35,225,200,14); // تم تغيير Y من 191 إلى 225
        labelPass.setFont(new Font("Tahoma",Font.BOLD,14));
        labelPass.setForeground(new Color(60, 80, 100));
        panel.add(labelPass);

        passwordField = new JPasswordField();
        passwordField.setBounds(200,225,150,20); // تم تغيير Y من 191 إلى 225
        panel.add(passwordField);

        // الأزرار
        addButton = new JButton("ADD");
        addButton.setBounds(100,300,120,30); // تم تغيير Y من 300 إلى 330
        addButton.setForeground(Color.white);
        addButton.setBackground(new Color(0, 153, 76));
        addButton.setFocusable(false);
        addButton.addActionListener(this);
        panel.add(addButton);

        backButton = new JButton("Back");
        backButton.setBounds(260,300,120,30); // تم تغيير Y من 300 إلى 330
        backButton.setForeground(Color.white);
        backButton.setBackground(new Color(70, 90, 110));
        backButton.setFocusable(false);
        backButton.addActionListener(this);
        panel.add(backButton);

        // إعدادات النافذة
        setUndecorated(true);
        this.setSize(850,450);
        this.setLayout(null);
        this.setLocation(300,250);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String id = textFieldID.getText();
        String name = textFieldName.getText();
        String phone = textFieldPhone.getText();
        String email = textFieldEmail.getText();
        String pass = new String(passwordField.getPassword());

        if (e.getSource() == addButton){
            if (id.isEmpty() || name.isEmpty() || phone.isEmpty() || email.isEmpty() || pass.isEmpty()){
                JOptionPane.showMessageDialog(this,"Please fill in all the fields!","Input Error",JOptionPane.WARNING_MESSAGE);
            }
            else if(!email.contains("@")|| !email.contains(".")){
                JOptionPane.showMessageDialog(this, "Invalid email address! It must contain '@' and a '.'", "Email Error", JOptionPane.ERROR_MESSAGE);
            }
            else if(pass.length() < 8 || (!pass.contains("$") && !pass.contains("#") && !pass.contains("!"))){
                JOptionPane.showMessageDialog(this,
                        "Password must be at least 8 characters long and contain at least one special character (!, #, $)",
                        "Password Error",
                        JOptionPane.ERROR_MESSAGE);
            }
            else {
                Connection connection = null;
                PreparedStatement statement = null;
                String db_url = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
                String sql_statement = "insert into users_table (userid , username , userphonenumber , user_email , user_password) values (? , ? , ? , ? , ?);";

                try {
                    connection = DriverManager.getConnection(db_url);
                    statement = connection.prepareStatement(sql_statement);

                    statement.setString(1, id);
                    statement.setString(2, name);
                    statement.setString(3, phone);
                    statement.setString(4, email);
                    statement.setString(5, pass);

                    statement.executeUpdate();
                    JOptionPane.showMessageDialog(this, "User added successfully!");

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                }
            }
        } else {
            this.setVisible(false);
        }
    }
}