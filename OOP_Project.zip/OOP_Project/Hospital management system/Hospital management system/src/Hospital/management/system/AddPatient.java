package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddPatient extends JFrame {
    AddPatient() {
        // Create panel
        JPanel panelDoctor = new JPanel();
        panelDoctor.setBounds(5, 5, 910, 510);
        panelDoctor.setBackground(new Color(230, 245, 255));
        panelDoctor.setLayout(null);
        this.add(panelDoctor);

        // Create AddPatient Icon
        ImageIcon addDoctorIcon = new ImageIcon("patient.png");
        Image image = addDoctorIcon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
        ImageIcon addDoctorIcon1 = new ImageIcon(image);
        JLabel labelIcon = new JLabel(addDoctorIcon1);
        labelIcon.setBounds(500, 60, 300, 300);
        panelDoctor.add(labelIcon);

        // Create label title
        JLabel labelTitle = new JLabel("ADD Patient");
        labelTitle.setBounds(124, 11, 222, 25);
        labelTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        labelTitle.setForeground(new Color(30, 60, 120));
        panelDoctor.add(labelTitle);

        // Patient ID Section
        JLabel labelPatientID = new JLabel("Patient ID:");
        labelPatientID.setBounds(25, 88, 80, 14);
        labelPatientID.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelPatientID.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelPatientID);

        JTextField textPatientID = new JTextField();
        textPatientID.setBounds(160, 88, 140, 20);
        panelDoctor.add(textPatientID);

        // Patient Name Section
        JLabel labelPatentName = new JLabel("Patient Name:");
        labelPatentName.setBounds(25, 129, 107, 14);
        labelPatentName.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelPatentName.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelPatentName);

        JTextField textPatientName = new JTextField();
        textPatientName.setBounds(160, 129, 140, 20);
        panelDoctor.add(textPatientName);

        // Patient Age Section
        JLabel labelPatientAge = new JLabel("Patient Age:");
        labelPatientAge.setBounds(25, 174, 115, 14);
        labelPatientAge.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelPatientAge.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelPatientAge);

        JTextField textPatientAge = new JTextField();
        textPatientAge.setBounds(160, 174, 140, 20);
        panelDoctor.add(textPatientAge);

        // Patient Status Section
        JLabel labelpatientStatues = new JLabel("Patient Status:");
        labelpatientStatues.setBounds(25, 216, 115, 14);
        labelpatientStatues.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelpatientStatues.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelpatientStatues);

        JTextField textPatientStatues = new JTextField();
        textPatientStatues.setBounds(160, 216, 140, 20);
        panelDoctor.add(textPatientStatues);

        // Reserve Time Section
        JLabel labelReserveTime = new JLabel("Reserve Time:");
        labelReserveTime.setBounds(25, 261, 115, 14);
        labelReserveTime.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelReserveTime.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelReserveTime);

        JTextField textReserveTime = new JTextField();
        textReserveTime.setBounds(160, 261, 140, 20);
        panelDoctor.add(textReserveTime);

        // Username Section
        JLabel labelUsername = new JLabel("Username:");
        labelUsername.setBounds(25, 300, 115, 14);
        labelUsername.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelUsername.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelUsername);

        JTextField textUsername = new JTextField();
        textUsername.setBounds(160, 300, 140, 20);
        panelDoctor.add(textUsername);

        // Password Section
        JLabel labelPassword = new JLabel("Password:");
        labelPassword.setBounds(25, 340, 115, 14);
        labelPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
        labelPassword.setForeground(new Color(70, 70, 70));
        panelDoctor.add(labelPassword);

        JPasswordField textPassword = new JPasswordField();
        textPassword.setBounds(160, 340, 140, 20);
        panelDoctor.add(textPassword);

        // Add Button
        JButton addButton = new JButton("Add");
        addButton.setBounds(120, 380, 89, 23);
        addButton.setBackground(new Color(76, 175, 80));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusable(false);
        panelDoctor.add(addButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = textPatientID.getText();
                String name = textPatientName.getText();
                String age = textPatientAge.getText();
                int intAge = 0;
                String status = textPatientStatues.getText();
                String reserveTime = textReserveTime.getText();
                String username = textUsername.getText();
                String password = new String(textPassword.getPassword());

                if (!id.isEmpty() && !name.isEmpty() && !age.isEmpty() &&
                        !status.isEmpty() && !reserveTime.isEmpty() &&
                        !username.isEmpty() && !password.isEmpty()) {

                    try {
                        intAge = Integer.parseInt(age);
                        if (intAge > 0) {
                            String db_url = "jdbc:sqlite:f:\\ObjectOrianted_Project\\Hospitaldb.db";
                            String sql = "INSERT INTO patient (patient_id, patient_name, age, status, username, password, reserved_time) VALUES (?,?,?,?,?,?,?)";

                            try (Connection connection = DriverManager.getConnection(db_url);
                                 PreparedStatement statement = connection.prepareStatement(sql)) {

                                statement.setString(1, id);
                                statement.setString(2, name);
                                statement.setString(3, age);
                                statement.setString(4, status);
                                statement.setString(5, username);
                                statement.setString(6, password);
                                statement.setString(7, reserveTime);

                                statement.executeUpdate();
                                JOptionPane.showMessageDialog(null, "Patient Added Successfully!");
                                setVisible(false);
                            }

                        } else {
                            JOptionPane.showMessageDialog(null, "Age must be greater than 0!");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Please enter a valid age!");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please fill all fields!");
                }
            }
        });

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setBounds(281, 380, 89, 23);
        backButton.setBackground(new Color(160, 160, 160));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusable(false);
        panelDoctor.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        // Frame settings
        this.setUndecorated(true);
        this.setSize(920, 520);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }
}