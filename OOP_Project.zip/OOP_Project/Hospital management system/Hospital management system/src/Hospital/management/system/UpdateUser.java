package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class UpdateUser extends JFrame {
    private JTextField fieldCurrentName, fieldNewName, fieldPhoneNubmer, fieldUserEmail;
    private JPasswordField fieldUserPass;

    public UpdateUser() {
        JPanel panel = new JPanel();
        panel.setBounds(5,5,940,440);
        panel.setBackground(new Color(180, 210, 230));
        panel.setLayout(null);
        this.add(panel);

        ImageIcon imageIcon = new ImageIcon("updated.png");
        Image image = imageIcon.getImage().getScaledInstance(300,300,Image.SCALE_SMOOTH);
        JLabel iconLabel = new JLabel(new ImageIcon(image));
        iconLabel.setBounds(500,60,300,300);
        panel.add(iconLabel);

        JLabel titleLabel = new JLabel("Update User Details");
        titleLabel.setBounds(124,11,260,25);
        titleLabel.setFont(new Font("Tahoma",Font.BOLD,20));
        titleLabel.setForeground(new Color(0, 51, 102));
        panel.add(titleLabel);

        addLabel(panel, "Current Username:", 25, 70);
        fieldCurrentName = new JTextField();
        fieldCurrentName.setBounds(25, 88, 140, 20);
        panel.add(fieldCurrentName);

        addLabel(panel, "New Username:", 25, 120);
        fieldNewName = new JTextField();
        fieldNewName.setBounds(25, 138, 140, 20);
        panel.add(fieldNewName);

        addLabel(panel, "Phone Number:", 25, 170);
        fieldPhoneNubmer = new JTextField();
        fieldPhoneNubmer.setBounds(25, 188, 140, 20);
        panel.add(fieldPhoneNubmer);

        addLabel(panel, "Email:", 25, 220);
        fieldUserEmail = new JTextField();
        fieldUserEmail.setBounds(25, 238, 140, 20);
        panel.add(fieldUserEmail);

        addLabel(panel, "Password:", 25, 270);
        fieldUserPass = new JPasswordField();
        fieldUserPass.setBounds(25, 288, 140, 20);
        panel.add(fieldUserPass);

        JButton updateButton = new JButton("UPDATE");
        updateButton.setBounds(25, 330, 100, 25);
        updateButton.setBackground(new Color(70, 130, 180));
        updateButton.setForeground(Color.white);
        updateButton.addActionListener(this::updateAction);
        panel.add(updateButton);

        JButton backButton = new JButton("BACK");
        backButton.setBounds(135, 330, 100, 25);
        backButton.setBackground(new Color(100, 120, 140));
        backButton.setForeground(Color.white);
        backButton.addActionListener(e -> setVisible(false));
        panel.add(backButton);

        this.setUndecorated(true);
        this.setSize(950,450);
        this.setLocation(350,225);
        this.setVisible(true);
    }

    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 150, 14);
        label.setFont(new Font("Tahoma", Font.PLAIN, 14));
        label.setForeground(new Color(0, 102, 204));
        panel.add(label);
    }

    private void updateAction(ActionEvent e) {
        String currentName = fieldCurrentName.getText();
        String newName = fieldNewName.getText();
        String phone = fieldPhoneNubmer.getText();
        String email = fieldUserEmail.getText();
        String pass = new String(fieldUserPass.getPassword());

        if (currentName.isEmpty() || newName.isEmpty() || phone.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Fill all fields");
            return;
        }

        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(null, "Invalid email");
            return;
        }

        if (pass.length() < 8 || (!pass.contains("!") && !pass.contains("#") && !pass.contains("$"))) {
            JOptionPane.showMessageDialog(null, "Password must have 8+ chars and !,#,$");
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db");
            PreparedStatement pstmt = conn.prepareStatement(
                    "UPDATE users_table SET username=?, userphonenumber=?, user_email=?, user_password=? WHERE username=?"
            );

            pstmt.setString(1, newName);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, pass);
            pstmt.setString(5, currentName);

            if (pstmt.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Update successful");
                fieldCurrentName.setText("");
                fieldNewName.setText("");
                fieldPhoneNubmer.setText("");
                fieldUserEmail.setText("");
                fieldUserPass.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "User not found");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database error");
        }
    }

    public static void main(String[] args) {
        new UpdateUser();
    }
}