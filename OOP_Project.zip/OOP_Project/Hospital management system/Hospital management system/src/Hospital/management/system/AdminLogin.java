package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminLogin extends JFrame implements ActionListener {
    JTextField textField;
//    I used the JPasswordField becuase it make the text Unvisible
    JPasswordField passwordField;
    JButton buttonLogin;
    JButton buttonCancel;

//I want to pass ont arguments to the Constructor is Image icon, and the title  /////////////////////////////////////
    AdminLogin(){
//        labelUsername
//        this is the labele next to the textField of the username
        JLabel nameLabel = new JLabel("Username: ");
//        this is the bounds of hte label like x-axis ,y-axis ,width ,height
        nameLabel.setBounds(40,20,100,30);
//        to determine the                  style  ,  type   , size of the font
        nameLabel.setFont(new Font("Tahoma",Font.BOLD,15));
//        the color of the font
        nameLabel.setForeground(new Color(51, 51, 51));

//       LabelPassword
//        to create lable password next to the textField
        JLabel password = new JLabel("Password: ");
        password.setBounds(40,70,100,30);
        password.setFont(new Font("Tahoma",Font.BOLD,15));
        password.setForeground(new Color(51,51,51));

//        to create the text field of the username
        textField = new JTextField();
        textField.setBounds(150,20,150,30);
        textField.setFont(new Font("Tahoma",Font.PLAIN,13));
        textField.setBackground(new Color(247, 247, 247));

//      to create password field
        passwordField = new JPasswordField();
        passwordField.setBounds(150,70,150,30);
        passwordField.setFont(new Font("Tahoma",Font.PLAIN,15));
        passwordField.setBackground(new Color(247, 247, 247));

//      to add ImageIcon
        ImageIcon imageIcon = new ImageIcon("Login(2).png");
//        resize the image to width 200 and height 200 and the quality of the image
//        This line converts the ImageIcon to an Image object using the getImage() method (SCale_smooth: is the quality of the picture)
        Image i1 = imageIcon.getImage().getScaledInstance(400,400,Image.SCALE_SMOOTH);
//    After resizing, the Image is converted back to an ImageIcon to be used in a Swing component like JLabel.
        ImageIcon imageIcon1 = new ImageIcon(i1);
//        create lebel contain the image after resize
        JLabel label = new JLabel(imageIcon1);
//        the Bounds of the lable
        label.setBounds(350,-80,400,400);

//      Add Login Button
        buttonLogin = new JButton("Login");
        buttonLogin.setBounds(40,140,120,30);
        buttonLogin.setFont(new Font("serif",Font.BOLD,15));
        buttonLogin.setBackground(new Color(0, 51, 102));
        buttonLogin.setForeground(Color.white);
        buttonLogin.setFocusable(false);
        buttonLogin.addActionListener(this);

//      Add Cancel Button
        buttonCancel = new JButton("Cancel");
        buttonCancel.setBounds(180,140,120,30);
        buttonCancel.setFont(new Font("serif",Font.BOLD,15));
        buttonCancel.setBackground(new Color(0, 51, 102));
        buttonCancel.setForeground(Color.white);
        buttonCancel.setFocusable(false);
        buttonCancel.addActionListener(this);

//      add the Cancel button to the frame
        this.add(buttonCancel);
//      add login button to the frame
        this.add(buttonLogin);
//        add the lable that containt the image on the frame
        this.add(label);
//       add the password field on the frame
        this.add(passwordField);
//        add the text field on the frame
        this.add(textField);
//        add the passWord label on the frame
        this.add(password);
//      to add the label on the frame
        this.add(nameLabel);
//        the colore of the frame using RGB
        this.getContentPane().setBackground(new Color(173,216,230));
//        to the end the program when click on icon x



//        this is the size of the frame
        this.setSize(750,300);
//        to start the frame in the middle
        this.setLocation(350,200);
//        to manage the items manual
        this.setLayout(null);
//        to make the frame visible
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttonLogin){
            try{
                String user = textField.getText();
                String pass = new String(passwordField.getPassword());
//                ////////////////////////////////////////////////////////////////////////////
//                I want to add download bar
                if (!user.isEmpty() && !pass.isEmpty() && user.equals("admin") && pass.equals("admin")){
                    setVisible(false);
                    Reception reception = new Reception();
                }else{
                    JOptionPane.showMessageDialog(this,"Incorrect username or password!","Login Error",JOptionPane.ERROR_MESSAGE);
                }
            }catch (Exception E){
//                print the detials of the error
                E.printStackTrace();
            }
        }else if (e.getSource() == buttonCancel){
            this.dispose();
            MainFrame mainFrame = new MainFrame();
        }

    }
}
