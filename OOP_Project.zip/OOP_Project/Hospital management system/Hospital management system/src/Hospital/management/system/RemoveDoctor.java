package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RemoveDoctor extends JFrame implements ActionListener {
    JTextField textFieldId;
    JButton removeButton;
    JButton backButton;

    RemoveDoctor(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,740,310);
        panel.setBackground(new Color(200, 220, 240));
        panel.setLayout(null);
        this.add(panel);

//        this is label for the title
        JLabel titleLabel = new JLabel("Remove Doctor");
        titleLabel.setBounds(220, 10, 300, 40);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
        titleLabel.setForeground(new Color(178, 34, 34));
        panel.add(titleLabel);

//        Create label for the DoctorID
        JLabel labelDoctorId= new JLabel("Doctor Name");
        labelDoctorId.setBounds(90,85,200,30);
        labelDoctorId.setFont(new Font("Tahoma",Font.BOLD,14));
        labelDoctorId.setForeground(new Color(33, 37, 41));
        panel.add(labelDoctorId);

//      textField next to the label of the DoctorID
        textFieldId = new JTextField();
        textFieldId.setBounds(200,85,200,30);
        panel.add(textFieldId);

//        remove button
        removeButton = new JButton("Remove");
        removeButton.setBounds(130, 160, 120, 40);
        removeButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        removeButton.setForeground(Color.WHITE);
        removeButton.setBackground(new Color(220, 53, 69));
        removeButton.setFocusable(false);
        removeButton.addActionListener(this);
        panel.add(removeButton);

//        Back button
        backButton = new JButton("Back");
        backButton.setBounds(300, 160, 120, 40);
        backButton.setFont(new Font("Tahoma",Font.BOLD,16));
        backButton.setForeground(Color.white);
        backButton.setBackground(new Color(0, 51, 102));
        backButton.setFocusable(false);
        backButton.addActionListener(this);
        panel.add(backButton);

//        create Image Icon
        ImageIcon imageIcon = new ImageIcon("removeDoctor.png");
        Image image = imageIcon.getImage().getScaledInstance(250,250,Image.SCALE_SMOOTH);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel labelIcon = new JLabel(imageIcon1);
        labelIcon.setBounds(450, 8, 300, 250);
        panel.add(labelIcon);

//      Removes title bar and window borders
        this.setUndecorated(true);
//        create frame
        this.setSize(750,300);
//        to start the frame in the middle
        this.setLocation(300,250);
//        to manage the items manual
        this.setLayout(null);
//        to make the frame visible
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String name = textFieldId.getText();

        if(e.getSource() == removeButton){
            if(name.isEmpty()){
                JOptionPane.showMessageDialog(this, "Please enter the DoctorID!", "Error", JOptionPane.WARNING_MESSAGE);
            }else {
//            this is part of omar to delete in the database

                String db_url = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
                String sql_statement = "delete from Doctor where lower(name) = lower(?)";
                Connection connection = null;
                PreparedStatement statement = null;

                try {
                    connection = DriverManager.getConnection(db_url);
                    statement = connection.prepareStatement(sql_statement);
                    statement.setString(1 , name);

                    statement.executeUpdate();

                    System.out.println("data has been deleted");

                    JOptionPane.showMessageDialog(null , "Doctor " + name + " has been Deleted");

                } catch (SQLException ex) {
                    System.out.println("data base error : ");
                    System.out.println(ex.getMessage());
                }

            }
        }else{
            this.setVisible(false);
            new DoctorManagement();
        }
    }
    }

