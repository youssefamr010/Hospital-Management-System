package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ShowUser extends JFrame {
    private DefaultTableModel model;
    private JTable table;

    public ShowUser() {
        // Create main panel
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 910, 470);
        panel.setBackground(new Color(230, 245, 255));
        panel.setLayout(null);
        this.add(panel);

        // Create table model with columns from image
        model = new DefaultTableModel();
        table = new JTable(model);

        // Add columns according to the image
        model.addColumn("userid");
        model.addColumn("username");
        model.addColumn("userphonenumber");
        model.addColumn("user_email");
        model.addColumn("user_password");

        // Add scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 30, 890, 380);
        panel.add(scrollPane);

        // Load data from database
        loadUserData();

        // Back button
        JButton buttonBack = new JButton("BACK");
        buttonBack.setBounds(400, 420, 120, 30);
        buttonBack.setBackground(new Color(120, 140, 170));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.addActionListener(e -> setVisible(false));
        panel.add(buttonBack);

        // Frame settings
        this.setUndecorated(true);
        this.setSize(920, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadUserData() {
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT userid, username, userphonenumber, user_email, user_password FROM users_table";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("userid"),
                        rs.getString("username"),
                        rs.getString("userphonenumber"),
                        rs.getString("user_email"),
                        rs.getString("user_password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading user data: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new ShowUser();
    }
}