package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.time.LocalDate;

public class PrescriptionForm extends JFrame {
    private JTextField txtPrescriptionId, txtMedications, txtNotes;
    private JComboBox<String> comboAppointments, comboDoctors, comboPatients;
    private JButton btnSave, btnBack, btnRefresh;

    public PrescriptionForm() {
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 910, 510);
        panel.setBackground(new Color(230, 245, 255));
        panel.setLayout(null);
        add(panel);

        JLabel title = new JLabel("New Prescription");
        title.setBounds(124, 11, 260, 25);
        title.setFont(new Font("Tahoma", Font.BOLD, 20));
        title.setForeground(new Color(40, 70, 110));
        panel.add(title);

        addField(panel, "Prescription ID:", 25, 60, txtPrescriptionId = new JTextField(), 160, 60);
        addField(panel, "Medications:", 25, 100, txtMedications = new JTextField(), 160, 100);
        addField(panel, "Notes:", 25, 140, txtNotes = new JTextField(), 160, 140);

        addCombo(panel, "Appointment ID:", 25, 180, comboAppointments = new JComboBox<>());
        loadAppointments();

        btnRefresh = new JButton("Refresh");
        btnRefresh.setBounds(370, 180, 100, 25);
        btnRefresh.setBackground(new Color(255, 165, 0));
        btnRefresh.addActionListener(e -> loadAppointments());
        panel.add(btnRefresh);

        addCombo(panel, "Doctor ID:", 25, 220, comboDoctors = new JComboBox<>());
        loadDoctors();

        addCombo(panel, "Patient ID:", 25, 260, comboPatients = new JComboBox<>());
        loadPatients();

        JLabel lblDate = new JLabel("Date Issued:");
        lblDate.setBounds(25, 300, 120, 20);
        panel.add(lblDate);
        JTextField txtDate = new JTextField(LocalDate.now().toString());
        txtDate.setBounds(160, 300, 200, 25);
        panel.add(txtDate);

        btnSave = new JButton("Save");
        btnSave.setBounds(100, 340, 100, 30);
        btnSave.setBackground(new Color(76, 175, 80));
        btnSave.setForeground(Color.WHITE);
        btnSave.addActionListener(e -> savePrescription(txtDate.getText()));
        panel.add(btnSave);

        btnBack = new JButton("Back");
        btnBack.setBounds(220, 340, 100, 30);
        btnBack.setBackground(new Color(160, 160, 160));
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> dispose());
        panel.add(btnBack);

        setUndecorated(true);
        setSize(920, 520);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addField(JPanel panel, String label, int x, int y, JTextField field, int fieldX, int fieldY) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(x, y, 120, 20);
        panel.add(lbl);
        field.setBounds(fieldX, fieldY, 200, 25);
        panel.add(field);
    }

    private void addCombo(JPanel panel, String label, int x, int y, JComboBox<String> combo) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(x, y, 120, 20);
        panel.add(lbl);
        combo.setBounds(x + 135, y, 200, 25);
        combo.setBackground(Color.WHITE);
        panel.add(combo);
    }

    private void loadAppointments() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT appointment_id FROM appointment")) {

            comboAppointments.removeAllItems();
            while(rs.next()) {
                String appId = rs.getString("appointment_id");
                comboAppointments.addItem(appId);
                System.out.println("Loaded appointment: " + appId);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + ex.getMessage());
        }
    }

    private void loadDoctors() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id FROM doctor")) {

            comboDoctors.removeAllItems();
            while(rs.next()) {
                String doctorId = rs.getString("id");
                comboDoctors.addItem(doctorId);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading doctors: " + ex.getMessage());
        }
    }

    private void loadPatients() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT patient_id FROM patient")) {

            comboPatients.removeAllItems();
            while(rs.next()) {
                String patientId = rs.getString("patient_id");
                comboPatients.addItem(patientId);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading patients: " + ex.getMessage());
        }
    }

    private void savePrescription(String date) {
        try {
            if (comboAppointments.getItemCount() == 0 ||
                    comboDoctors.getItemCount() == 0 ||
                    comboPatients.getItemCount() == 0) {
                JOptionPane.showMessageDialog(this, "No data available!");
                return;
            }

            if (txtPrescriptionId.getText().isEmpty() ||
                    txtMedications.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fill required fields!");
                return;
            }

            String sql = "INSERT INTO prescription VALUES(?,?,?,?,?,?,?)";

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, txtPrescriptionId.getText());
                pstmt.setString(2, txtMedications.getText());
                pstmt.setString(3, txtNotes.getText());
                pstmt.setString(4, date);
                pstmt.setString(5, comboAppointments.getSelectedItem().toString());
                pstmt.setString(6, comboDoctors.getSelectedItem().toString());
                pstmt.setString(7, comboPatients.getSelectedItem().toString());

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Prescription saved!");
                dispose();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new PrescriptionForm();
    }
}