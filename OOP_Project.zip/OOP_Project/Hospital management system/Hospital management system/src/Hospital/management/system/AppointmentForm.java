package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.time.LocalDate;

public class AppointmentForm extends JFrame {
    private JComboBox<String> comboPatients, comboDoctors, comboStatus;
    private JTextField txtCreatedDate, txtUpdatedDate;
    private JButton btnSave, btnBack;

    public AppointmentForm() {
        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 910, 510);
        panel.setBackground(new Color(230, 245, 255));
        panel.setLayout(null);
        add(panel);

        JLabel title = new JLabel("New Appointment");
        title.setBounds(124, 11, 260, 25);
        title.setFont(new Font("Tahoma", Font.BOLD, 20));
        title.setForeground(new Color(40, 70, 110));
        panel.add(title);

        addCombo(panel, "Patient:", 25, 60, comboPatients = new JComboBox<>());
        addCombo(panel, "Doctor:", 25, 100, comboDoctors = new JComboBox<>());
        addCombo(panel, "Status:", 25, 140, comboStatus = new JComboBox<>(new String[]{"Scheduled", "Completed", "Cancelled"}));

        addField(panel, "Created Date:", 25, 180, txtCreatedDate = new JTextField(LocalDate.now().toString()), 160, 180);
        addField(panel, "Updated Date:", 25, 220, txtUpdatedDate = new JTextField(LocalDate.now().toString()), 160, 220);

        btnSave = createButton("Save", 100, 260, new Color(76, 175, 80));
        btnSave.addActionListener(this::saveAppointment);
        panel.add(btnSave);

        btnBack = createButton("Back", 220, 260, new Color(160, 160, 160));
        btnBack.addActionListener(e -> dispose());
        panel.add(btnBack);

        loadPatients();
        loadDoctors();

        setUndecorated(true);
        setSize(920, 520);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addField(JPanel panel, String label, int x, int y, JTextField field, int fieldX, int fieldY) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(x, y, 120, 20);
        panel.add(lbl);
        field.setBounds(fieldX, fieldY, 200, 25);
        panel.add(field);
    }

    private void addCombo(JPanel panel, String label, int x, int y, JComboBox<String> combo) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(x, y, 120, 20);
        panel.add(lbl);
        combo.setBounds(x + 135, y, 200, 25);
        panel.add(combo);
    }

    private JButton createButton(String text, int x, int y, Color bg) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, 100, 30);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        return btn;
    }

    private void loadPatients() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT patient_id, patient_name FROM patient")) {

            while(rs.next()) {
                comboPatients.addItem(rs.getString("patient_id") + " - " + rs.getString("patient_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading patients");
            System.out.println(ex.getMessage());
        }
    }

    private void loadDoctors() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, name FROM doctor")) {

            while(rs.next()) {
                comboDoctors.addItem(rs.getString("id") + " - " + rs.getString("name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading doctors");
            System.out.println(ex.getMessage());
        }
    }

    private void saveAppointment(ActionEvent e) {
        try {
            String patientId = comboPatients.getSelectedItem().toString().split(" - ")[0];
            String doctorId = comboDoctors.getSelectedItem().toString().split(" - ")[0];
            String status = comboStatus.getSelectedItem().toString();
            String createdDate = txtCreatedDate.getText();
            String updatedDate = txtUpdatedDate.getText();

            String sql = "INSERT INTO appointment (appointment_status, created_date, updated_date, doctor_id, patient_id) " +
                    "VALUES (?, ?, ?, ?, ?)";

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:F:\\ObjectOrianted_Project\\HospitalDB.db");
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, status);
                pstmt.setString(2, createdDate);
                pstmt.setString(3, updatedDate);
                pstmt.setString(4, doctorId);
                pstmt.setString(5, patientId);

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Appointment saved!");
                dispose();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving appointment");
        }
    }

    public static void main(String[] args) {
        new AppointmentForm();
    }
}