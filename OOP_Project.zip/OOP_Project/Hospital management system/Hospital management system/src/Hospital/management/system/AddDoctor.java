package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddDoctor extends JFrame {

    AddDoctor() {
        // Create panel
        JPanel panelDoctor = new JPanel();
        panelDoctor.setBounds(5, 5, 910, 510);
        panelDoctor.setBackground(new Color(230, 245, 255));
        panelDoctor.setLayout(null);
        this.add(panelDoctor);

        // Create AddDoctor Icon
        ImageIcon addDoctorIcon = new ImageIcon("addDoctor.png");
        Image image = addDoctorIcon.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);
        ImageIcon addDoctorIcon1 = new ImageIcon(image);
        JLabel labelIcon = new JLabel(addDoctorIcon1);
        labelIcon.setBounds(500, 60, 300, 300);
        panelDoctor.add(labelIcon);

        // Create label title
        JLabel labelTitle = new JLabel("ADD Doctor");
        labelTitle.setBounds(124, 11, 222, 25);
        labelTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        labelTitle.setForeground(new Color(30, 60, 120));
        panelDoctor.add(labelTitle);

        // Create input fields
        JTextField textDoctorID = createInputField(160, 88);
        JTextField textDoctorName = createInputField(160, 129);
        JTextField textDoctorSpeciality = createInputField(160, 174);
        JTextField textDoctorSalary = createInputField(160, 216);
        JTextField textDoctorPhone = createInputField(160, 261);
        JTextField textUsername = createInputField(160, 302);
        JPasswordField textPassword = new JPasswordField();
        textPassword.setBounds(160, 343, 140, 20);

        // Add labels
        addLabel(panelDoctor, "Doctor ID:", 25, 88);
        addLabel(panelDoctor, "Doctor Name:", 25, 129);
        addLabel(panelDoctor, "Speciality:", 25, 174);
        addLabel(panelDoctor, "Salary:", 25, 216);
        addLabel(panelDoctor, "Phone:", 25, 261);
        addLabel(panelDoctor, "Username:", 25, 302);
        addLabel(panelDoctor, "Password:", 25, 343);

        // Department Choice
        Choice choiceDepartment = new Choice();
        choiceDepartment.setBounds(160, 384, 140, 20);
        populateDepartments(choiceDepartment);
        addLabel(panelDoctor, "Department:", 25, 384);

        // Add components to panel
        panelDoctor.add(textDoctorID);
        panelDoctor.add(textDoctorName);
        panelDoctor.add(textDoctorSpeciality);
        panelDoctor.add(textDoctorSalary);
        panelDoctor.add(textDoctorPhone);
        panelDoctor.add(textUsername);
        panelDoctor.add(textPassword);
        panelDoctor.add(choiceDepartment);

        // Add Buttons
        JButton addButton = createButton("Add", 120, 425, new Color(76, 175, 80));
        JButton backButton = createButton("Back", 281, 425, new Color(160, 160, 160));

        addButton.addActionListener(e -> handleAddDoctor(
                textDoctorID,
                textDoctorName,
                textDoctorSpeciality,
                textDoctorSalary,
                textDoctorPhone,
                textUsername,
                textPassword,
                choiceDepartment
        ));

        backButton.addActionListener(e -> this.setVisible(false));

        panelDoctor.add(addButton);
        panelDoctor.add(backButton);

        // Frame settings
        this.setUndecorated(true);
        this.getContentPane().setBackground(new Color(210, 235, 250));
        this.setSize(920, 520);
        this.setLocation(350, 217);
        this.setVisible(true);
    }

    private JTextField createInputField(int x, int y) {
        JTextField field = new JTextField();
        field.setBounds(x, y, 140, 20);
        return field;
    }

    private void addLabel(JPanel panel, String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 115, 14);
        label.setFont(new Font("Tahoma", Font.PLAIN, 14));
        label.setForeground(new Color(70, 70, 70));
        panel.add(label);
    }

    private JButton createButton(String text, int x, int y, Color color) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 89, 23);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusable(false);
        return button;
    }

    private void populateDepartments(Choice choice) {
        final String DB_URL = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT dept_name FROM Department")) {

            while (rs.next()) {
                choice.add(rs.getString("dept_name"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading departments!", "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void handleAddDoctor(JTextField idField,
                                 JTextField nameField,
                                 JTextField specialityField,
                                 JTextField salaryField,
                                 JTextField phoneField,
                                 JTextField usernameField,
                                 JPasswordField passwordField,
                                 Choice departmentChoice) {

        String id = idField.getText();
        String name = nameField.getText();
        String speciality = specialityField.getText();
        String salary = salaryField.getText();
        String phone = phoneField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String department = departmentChoice.getSelectedItem();

        if (validateInputs(id, name, speciality, salary, phone, username, password)) {
            try {
                int departmentId = getDepartmentId(department);
                if (departmentId == -1) {
                    JOptionPane.showMessageDialog(null, "Invalid department selected!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try (Connection conn = DriverManager.getConnection("jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db");
                     PreparedStatement pstmt = conn.prepareStatement(
                             "INSERT INTO Doctor(id, name, speciality, department_id, salary, phone, username, password) " +
                                     "VALUES(?,?,?,?,?,?,?,?)")) {

                    pstmt.setString(1, id);
                    pstmt.setString(2, name);
                    pstmt.setString(3, speciality);
                    pstmt.setInt(4, departmentId);
                    pstmt.setInt(5, Integer.parseInt(salary));
                    pstmt.setString(6, phone);
                    pstmt.setString(7, username);
                    pstmt.setString(8, password);

                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    this.setVisible(false);

                } catch (SQLException ex) {
                    handleDatabaseError(ex);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid salary format!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private int getDepartmentId(String departmentName) throws SQLException {
        final String DB_URL = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement("SELECT dept_id FROM Department WHERE dept_name = ?")) {

            pstmt.setString(1, departmentName);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("dept_id");
            }
        }
        return -1;
    }

    private boolean validateInputs(String... inputs) {
        for (String input : inputs) {
            if (input == null || input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields are required!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }

        try {
            int salary = Integer.parseInt(inputs[3]);
            if (salary <= 0) {
                JOptionPane.showMessageDialog(null, "Salary must be positive!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid salary format!", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void handleDatabaseError(SQLException ex) {
        String errorMessage;
        if (ex.getMessage().contains("UNIQUE constraint failed")) {
            errorMessage = "Duplicate entry! Doctor ID or Username already exists!";
        } else {
            errorMessage = "Database error: " + ex.getMessage();
        }
        JOptionPane.showMessageDialog(null, errorMessage, "Database Error", JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }

    public static void main(String[] args) {
        new AddDoctor();
    }
}