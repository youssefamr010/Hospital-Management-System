package Hospital.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class SearchPatient extends JFrame {
    private DefaultTableModel model;
    private JTable table;
    private JTextField searchField;

    public SearchPatient() {
        // Main panel setup
        JPanel panelPatient = new JPanel();
        panelPatient.setBounds(5, 5, 910, 470);
        panelPatient.setBackground(new Color(230, 245, 255));
        panelPatient.setLayout(null);
        this.add(panelPatient);

        // Window title
        JLabel labelTitle = new JLabel("Search For Patient");
        labelTitle.setBounds(250, 11, 250, 31);
        labelTitle.setFont(new Font("Arial", Font.BOLD, 20));
        labelTitle.setForeground(new Color(40, 70, 110));
        panelPatient.add(labelTitle);

        // Search field components
        JLabel labelIDSearch = new JLabel("Patient ID/Name:");
        labelIDSearch.setBounds(50, 73, 120, 20);
        labelIDSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panelPatient.add(labelIDSearch);

        searchField = new JTextField();
        searchField.setBounds(175, 73, 200, 30);
        panelPatient.add(searchField);

        // Table setup with columns from image
        model = new DefaultTableModel();
        table = new JTable(model);
        model.addColumn("patient_id");
        model.addColumn("patient_name");
        model.addColumn("age");
        model.addColumn("status");
        model.addColumn("reserved_time");
        model.addColumn("username");
        model.addColumn("password");

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 150, 890, 250);
        panelPatient.add(scrollPane);

        // Control buttons
        JButton searchButton = new JButton("Search");
        searchButton.setBounds(200, 420, 120, 25);
        searchButton.setBackground(new Color(60, 100, 130));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(this::searchAction);
        panelPatient.add(searchButton);

        JButton buttonBack = new JButton("BACK");
        buttonBack.setBounds(450, 420, 120, 30);
        buttonBack.setBackground(new Color(120, 140, 170));
        buttonBack.setForeground(Color.WHITE);
        buttonBack.addActionListener(e -> setVisible(false));
        panelPatient.add(buttonBack);

        // Initial data load
        loadAllPatients();

        // Window settings
        this.setUndecorated(true);
        this.setSize(920, 480);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void loadAllPatients() {
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM patient";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getInt("age"),
                        rs.getString("status"),
                        rs.getString("reserved_time"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Data loading error: " + ex.getMessage());
        }
    }

    private void searchAction(ActionEvent e) {
        String searchTerm = searchField.getText().trim();
        String dbUrl = "jdbc:sqlite:f:\\ObjectOrianted_Project\\HospitalDB.db";
        String sql = "SELECT * FROM patient WHERE patient_id = ? OR patient_name LIKE ?";

        try (Connection conn = DriverManager.getConnection(dbUrl);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, searchTerm);
            pstmt.setString(2, "%" + searchTerm + "%");

            ResultSet rs = pstmt.executeQuery();
            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("patient_id"),
                        rs.getString("patient_name"),
                        rs.getInt("age"),
                        rs.getString("status"),
                        rs.getString("reserved_time"),
                        rs.getString("username"),
                        rs.getString("password")
                });
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No matching records found");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new SearchPatient();
    }
}