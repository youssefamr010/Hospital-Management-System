package Hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame implements ActionListener {
    JButton buttonPatient;
    JButton buttonDoctor;
    JButton buttonAdmin;
    MainFrame(){

//        Patient Button
        buttonPatient = new JButton("Patient");
        buttonPatient.setBounds(50, 100, 150, 50);
        buttonPatient.setFont(new Font("Tahoma", Font.BOLD, 16));
        buttonPatient.setBackground(new Color(33, 97, 140));
        buttonPatient.setForeground(Color.white);
        buttonPatient.setFocusable(false);
        buttonPatient.addActionListener(this);

//        Doctor Button
        buttonDoctor = new JButton("Doctor");
        buttonDoctor.setBounds(50, 200, 150, 50);
        buttonDoctor.setFont(new Font("Tahoma", Font.BOLD, 16));
        buttonDoctor.setBackground(new Color(33, 97, 140));
        buttonDoctor.setForeground(Color.white);
        buttonDoctor.setFocusable(false);
        buttonDoctor.addActionListener(this);


//        Admin Button
        buttonAdmin = new JButton("Admin");
        buttonAdmin.setBounds(50, 300, 150, 50);
        buttonAdmin.setFont(new Font("Tahoma", Font.BOLD, 16));
        buttonAdmin.setBackground(new Color(33, 97, 140));
        buttonAdmin.setForeground(Color.white);
        buttonAdmin.setFocusable(false);
        buttonAdmin.addActionListener(this);

//      The title of the frame
        JLabel titleLabel = new JLabel("Hospital Management System");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        titleLabel.setBounds(0, 25, 600, 30);
//        This method is used to center-align the text horizontally inside the JLabel
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);


//        To Set the image on the frame
        ImageIcon imageIcon = new ImageIcon("LogoSystem.png");
//        to resize the image and to control on the quality
        Image image = imageIcon.getImage().getScaledInstance(400,400,Image.SCALE_SMOOTH);
        //    After resizing, the Image is converted back to an ImageIcon to be used in a Swing component like JLabel.
        ImageIcon imageIcon1 = new ImageIcon(image);
//        add the ImageIcon to the label
        JLabel labelImage = new JLabel(imageIcon1);
        labelImage.setBounds(225,65,400,300);


//       add the label that contain the image on the frame
        this.add(labelImage);
//       add the label that contain the title
        this.add(titleLabel);
//       add the Admin Button to the frame
        this.add(buttonAdmin);
//       add the Doctor Button to the frame
        this.add(buttonDoctor);
//      add Patient Button to the frame
        this.add(buttonPatient);
        this.setSize(600, 500);
        this.setLocation(350,100);
        this.getContentPane().setBackground(new Color(173,216,230));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttonAdmin){
            this.dispose();
            AdminLogin login = new AdminLogin();
        }else if(e.getSource() == buttonPatient){
            this.dispose();
            PatientLogin patient = new PatientLogin();
        }else if(e.getSource() == buttonDoctor){
            this.dispose();
            DoctorLogin doctorLogin = new DoctorLogin();
        }
    }
}
